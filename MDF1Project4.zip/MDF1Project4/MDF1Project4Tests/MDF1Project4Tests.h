//
//  MDF1Project4Tests.h
//  MDF1Project4Tests
//
//  Created by Brenna Pavlinchak on 1/27/14.
//  Copyright (c) 2014 Brenna Pavlinchak. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MDF1Project4Tests : SenTestCase

@end
